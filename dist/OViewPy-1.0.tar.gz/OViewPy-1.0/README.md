# PilotGaea O'View Map Server API for Python

使用 PilotGaea O'View Map Server API for Python 在 Python 中處理O'View Map Server發布的地圖和地理空間數據。

這個library可讀取、編輯、分析、上架由O'View Map Server發布之地圖圖像與向量資料，並可透過API操作輸出及發佈處理後的成果。

此library只支援由 O'View Map Server 發佈的圖資，暫不支援外部資料處理。